package com.example.casinoroulette;

// Classe pour stocker une mise
public class Bet {
    String key; // Numéro ou couleur
    int value;  // Valeur de la mise

    Bet(String key, int value) {
        this.key = key;
        this.value = value;
    }
}
